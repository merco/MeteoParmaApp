﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Control
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UIMap : ContentView
    {
      
        public Data.WeatherInfo InfoMain
        { get; set; }
      
        public UIMap()
        {
            InitializeComponent();
        }
        private void FillDataMap(string text, string x1, string x2, string x3, string t0)
        {
            lbl.Text = text.Trim();
            string k = x1;
            string b64 = InfoMain.i[k];
            bassa.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(b64)));


            k = x2;
            b64 = InfoMain.i[k];
            centro.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(b64)));



            k = x3;
            b64 = InfoMain.i[k];
            alto.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(b64)));



            k = t0;
            if (!string.IsNullOrEmpty(k))
            {
                b64 = InfoMain.i[k];
                temp.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(b64)));

            }
        }
        public void ShowData(int idx,string Shape)
        {
           
            if (InfoMain == null) return;
          
            bck.Source= Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(InfoMain.imgParma)));


            if (Shape=="M")
            {
                FillDataMap(InfoMain.p[idx].mattina, InfoMain.p[idx].mattina_1, InfoMain.p[idx].mattina_2, InfoMain.p[idx].mattina_3, InfoMain.p[idx].mattina_T);
            }
            if (Shape == "P")
            {
                FillDataMap(InfoMain.p[idx].pomeriggio, InfoMain.p[idx].pomeriggio_1, InfoMain.p[idx].pomeriggio_2, InfoMain.p[idx].pomeriggio_3, InfoMain.p[idx].pomeriggio_T);
            }
            if (Shape == "S")
            {
                FillDataMap(InfoMain.p[idx].sera, InfoMain.p[idx].sera_1, InfoMain.p[idx].sera_2, InfoMain.p[idx].sera_3, InfoMain.p[idx].sera_T);
            }

        }
    }
}