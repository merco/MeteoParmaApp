﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace MeteoParmaApp.Data
{
    public class PCDataDays : System.Collections.Generic.List<PCDatas>
    {
        public Color GetWorstColor(int idx)
        {
            PCDatas pcd = this[idx];
            return pcd.GetWorstColor();
        }
    }
    public class PCDatas : System.Collections.Generic.List<PCData>
    {
        public Color GetWorstColor ()
        {
            int vo = 0;

            foreach (PCData d in this)
            {
                if (d.AtoInt() > vo) vo = d.AtoInt();
               



            }

            return PCData.RISK_COLORS[vo];

        }
    }
    public class PCData
    {
        public static Color RISK_COLOR_GREEN = Color.GreenYellow;
        public static Color RISK_COLOR_YELLOW = Color.Yellow;
        public static Color RISK_COLOR_ORANGE = Color.Orange;
        public static Color RISK_COLOR_RED = Color.PaleVioletRed;
        public static Color[] RISK_COLORS = { RISK_COLOR_GREEN, RISK_COLOR_YELLOW, RISK_COLOR_ORANGE, RISK_COLOR_RED };
        public string R
        { get; set; }
        public string I
        { get; set; }
        public string A  ///verde (default) | gialla | arancione | rossa 
        { get; set; }
        public int AtoInt ()
        {
            string A1 = A.ToUpper().Trim();

            switch (A1)
            {
                case "VERDE": return 0;
                case "GIALLA": return 1;
                case "ARANCIONE": return 2;
                case "ROSSA": return 3;

            }
            return 0;
        }
        public Color AtoColor ()
        {
            return RISK_COLORS[AtoInt()];
        }
        public Color getColor
        {

            get
            {
                return AtoColor();
            }
        }
        public string RUpper
        {

            get
            {
                return R.ToUpper();
            }
        }

        public String Ico
        {

            get
            {
              switch (RUpper)
                {

                    case "IDROGEOLOGICO": return "\uf0ac";
                    case "IDRAULICO": return "\uf773";
                    case "TEMPORALI": return "\uf740";
                }
                return "";
            }
        }
        public PCData()
        {
            R = "";
            I = "";
            A = "";
        }

    }
}
