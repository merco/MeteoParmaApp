﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MeteoParmaApp.Data
{
    public class WrfInfos : System.Collections.Generic.List<string>
    {

    }
    public class WebCamInfo
    {
        public string imm
        { get; set; }
        public string text
        { get; set; }
        public string url
        { get; set; }
    }
    public class WebCamInfos : System.Collections.Generic.List<WebCamInfo>
    {

    }
    public class WeatherInfo
    {
        public string imgTemp
        { get; set; }
        public string imgParma
        { get; set; }
        public string imgParmaTemp
        { get; set; }
        public string imgParmaTempLeg
        { get; set; }
        public string nowCasting
        { get; set; }
        
        public System.Collections.Generic.Dictionary<string,string> i
        { get; set; }
        public System.Collections.Generic.List<string> fredde
        { get; set; }
        public System.Collections.Generic.List<string> calde
        { get; set; }
        public System.Collections.Generic.List<string> ventose
        { get; set; }
        public System.Collections.Generic.List<string> piovose
        { get; set; }

        public System.Collections.Generic.List<WeatherInfoDetails> p
        { get; set; }
        public WeatherInfo()
        {
            imgTemp = "";
            imgParma = "";
            imgParmaTempLeg = "";
            nowCasting = "";
            imgParmaTemp = "";
            i = new System.Collections.Generic.Dictionary<string, string>();
            fredde = new System.Collections.Generic.List<string>();
            calde = new System.Collections.Generic.List<string>();
            ventose = new System.Collections.Generic.List<string>();
            piovose = new System.Collections.Generic.List<string>();
            p = new System.Collections.Generic.List<WeatherInfoDetails>();
        }
        public string freddeAsString ()
        {
            return string.Join("\r\n", fredde.ToArray());
        }
        public string caldeAsString()
        {
            return string.Join("\r\n", calde.ToArray());
        }
        public string ventoseAsString()
        {
            return string.Join("\r\n", ventose.ToArray());
        }
        public string piovoseAsString()
        {
            return string.Join("\r\n", piovose.ToArray());
        }
        public string NowCastingDate()
        {

            if (string.IsNullOrEmpty(nowCasting)) return "";

            if (!nowCasting.Contains("-")) return "";


            return nowCasting.Split('-')[0].Trim(); ;
        }
        public string NowCastingPrev()
        {

            if (string.IsNullOrEmpty(nowCasting)) return "";

            if (!nowCasting.Contains("-")) return "";


            return nowCasting.Split('-')[1].Trim(); ;
        }
    }
      
    public class WeatherInfoDetails
    {
        
        public string day
        { get; set; }
        public string lastUpdate
        { get; set; }
        public string mattina
        { get; set; }
        public string mattina_1
        { get; set; }
        public string mattina_2
        { get; set; }
        public string mattina_3
        { get; set; }
        public string mattina_T
        { get; set; }

        public string pomeriggio
        { get; set; }
        public string pomeriggio_1
        { get; set; }
        public string pomeriggio_2
        { get; set; }
        public string pomeriggio_3
        { get; set; }
        public string pomeriggio_T
        { get; set; }

        public string sera
        { get; set; }
        public string sera_1
        { get; set; }
        public string sera_2
        { get; set; }
        public string sera_3
        { get; set; }
        public string sera_T
        { get; set; }

        public string previsione
        { get; set; }
        public string temperature
        { get; set; }
        public string venti
        { get; set; }

        public WeatherInfoDetails()
        {
            day = "";
            lastUpdate = "";
            mattina = "";
            mattina_1 = "";
            mattina_2 = "";
            mattina_3 = "";
            mattina_T = "";

            pomeriggio = "";
            pomeriggio_1 = "";
            pomeriggio_2 = "";
            pomeriggio_3 = "";
            pomeriggio_T = "";

            sera = "";
            sera_1 = "";
            sera_2 = "";
            sera_3 = "";
            sera_T = "";

            previsione = "";
            temperature = "";
            venti = "";
        }

        public String ShortDay()
        {
            string s = day.Trim().ToUpper();
            string[] fld = s.Split(' ');

            return fld[0].Substring(0, 3) + " " + fld[1];
        }


    }
}
