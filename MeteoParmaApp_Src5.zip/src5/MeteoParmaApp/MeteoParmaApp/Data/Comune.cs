﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MeteoParmaApp.Data
{
    public class Comune
    {
        public string Cod
        { get; set; }
        public string Nome
        { get; set; }
        public Comune()
        {
            Cod = "";
            Nome = "";
        }
        public override string ToString()
        {
            return Nome;
        }
    }

    public class Comuni :System.Collections.Generic.List<Comune>
    {
       
    }
}
