﻿using MeteoParmaApp.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MeteoParmaApp.Core
{
    public class Session
    {
        System.Reflection.Assembly _localAssembly;
        String _assemblyName = "MeteoParmaApp";
        public static string COMUNE_KEY = "CodiceComune";
        public String BaseUrl
        { get; set; }

        public String CodiceComune
        { get; set; }
        public String UrlPrevision
        { get; set; }
        public String UrlWrf
        { get; set; }
        public String UrlWebcam
        { get; set; }
        public String UrlPC
        { get; set; }
        public bool MainDataLoaded
        { get; set; }
        public Data.WeatherInfo CurrentWeatherInfo
        { get; set; }
        public Data.WrfInfos CurrentWrfInfo
        { get; set; }
        public Data.PCDataDays CurrentPCInfo
        { get; set; }
        public Data.WebCamInfos CurrentWebCamInfo
        { get; set; }

        public Data.Comuni CurrentComuni
        { get; set; }
        public Session()
        {
            BaseUrl = "https://davidemercanti.altervista.org/MeteoPR/";
            UrlPrevision = BaseUrl + "grabMeteo.php";
            UrlWrf = BaseUrl + "wrf.php";
            UrlWebcam = BaseUrl + "webcams.php";
            UrlPC = BaseUrl + "grabPC.php?C=%CODICECOMUNE%";
            CurrentWeatherInfo = null;
            MainDataLoaded = false;
            _localAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            CodiceComune = ""; 
            if (Application.Current.Properties.ContainsKey(COMUNE_KEY))
            {
                CodiceComune = Application.Current.Properties[COMUNE_KEY] as string;
             
            }
            if (string.IsNullOrEmpty(CodiceComune)) CodiceComune = "034027";  //Parma
        }
        public void SaveComune()
        {
            Application.Current.Properties[COMUNE_KEY] = CodiceComune;
        }

        private string GetInternalData(String fileName)
        {
            System.IO.Stream tStream = _localAssembly.GetManifestResourceStream(_assemblyName + ".InternalData." + fileName);
            string result = "";
            using (StreamReader reader = new StreamReader(tStream))
            {
                result = reader.ReadToEnd();
            }
            tStream.Dispose();
            return result;
        }
        private  async Task<byte[]> GetURLContentsAsync(string url, bool GZip, string PostData)
        {
            // The downloaded resource ends up in the variable named content.
            var content = new MemoryStream();

            // Initialize an HttpWebRequest for the current URL.
            var webReq = (HttpWebRequest)WebRequest.Create(url);
            if (GZip)
                webReq.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip,deflate");

            if (!string.IsNullOrEmpty(PostData))
            {
                webReq.Method = "POST";
                byte[] lbPostBuffer = Encoding.Default.GetBytes(PostData);

                webReq.ContentLength = lbPostBuffer.Length;

                Stream PostStream = webReq.GetRequestStream();
                PostStream.Write(lbPostBuffer, 0, lbPostBuffer.Length);
                PostStream.Close();
            }

            // Send the request to the Internet resource and wait for
            // the response.
            using (WebResponse response = await webReq.GetResponseAsync())

            // The previous statement abbreviates the following two statements.

            //Task<WebResponse> responseTask = webReq.GetResponseAsync();
            //using (WebResponse response = await responseTask)
            {
                // Get the data stream that is associated with the specified url.
                using (Stream responseStream = response.GetResponseStream())
                {
                    // Read the bytes in responseStream and copy them to content.
                    await responseStream.CopyToAsync(content);

                    // The previous statement abbreviates the following two statements.

                    // CopyToAsync returns a Task, not a Task<T>.
                    //Task copyTask = responseStream.CopyToAsync(content);

                    // When copyTask is completed, content contains a copy of
                    // responseStream.
                    //await copyTask;

                   
                }
            }
            // Return the result as a byte array.
            return content.ToArray();
        }
     
        private async System.Threading.Tasks.Task<string> _getURL(string URL)
        {
            string responseJson = "";
            HttpClient _client = null;
            try
            {

                HttpClientHandler handler = new HttpClientHandler()
                {
                    AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
                };

                _client = new HttpClient(handler);
               
                _client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip,deflate");
                // String content = await _client.GetStringAsync(URL + "?D=" + long.Parse(DateTime.Now.ToString("yyyyMMddHHmmss")));


                String content = "";
                
                if (!URL.Contains("?")) content=await _client.GetStringAsync(URL + "?D=" + long.Parse(DateTime.Now.ToString("yyyyMMddHHmmss")));
                else content= await _client.GetStringAsync(URL + "&D=" + long.Parse(DateTime.Now.ToString("yyyyMMddHHmmss")));

                responseJson = content;

            }
            catch (Exception err)
            {
                responseJson = "!!! " + err.Message;
            }
            finally
            {
                _client.Dispose();
            }
            return responseJson;
        }
        public async System.Threading.Tasks.Task<string> GetWeatherData()
        {
            var response = await _getURL(UrlPrevision);

            if (response.StartsWith("!!!")) return response;


            CurrentWeatherInfo = JsonConvert.DeserializeObject<Data.WeatherInfo>(response);
          
            MainDataLoaded = true;
            return "";
        }
        public async System.Threading.Tasks.Task<string> GetWrfData()
        {
            var response = await _getURL(UrlWrf);

            if (response.StartsWith("!!!")) return response;


            CurrentWrfInfo = JsonConvert.DeserializeObject<Data.WrfInfos>(response);
        
            return "";
        }
        public async System.Threading.Tasks.Task<string> GetWebcamData()
        {
            var response = await _getURL(UrlWebcam);

            if (response.StartsWith("!!!")) return response;


            CurrentWebCamInfo = JsonConvert.DeserializeObject<Data.WebCamInfos>(response);
            foreach (WebCamInfo ii in CurrentWebCamInfo)
            {
                ii.url = ii.url + "?D=" + long.Parse(DateTime.Now.ToString("yyyyMMddHHmm"));
            }
            return "";
        }
        public async System.Threading.Tasks.Task<string> GetPCData()
        {

            string tmp = UrlPC.Replace("%CODICECOMUNE%", CodiceComune);
            var response = await _getURL(tmp);

            if (response.StartsWith("!!!")) return response;


            CurrentPCInfo = JsonConvert.DeserializeObject<Data.PCDataDays>(response);
            foreach ( PCDatas ii in CurrentPCInfo)
            {
               
                if (ii!=null)
                {
                    foreach (PCData pp in ii)
                    {
                        pp.A = pp.A.ToUpper();
                    }
                }
             
            }
            return "";
        }
        public void GetComuni()
        {
            CurrentComuni = new Data.Comuni();

            string tmp = "";


            tmp = GetInternalData("comuniPR.json");
            if (string.IsNullOrEmpty(tmp)) return;
            CurrentComuni = JsonConvert.DeserializeObject<Data.Comuni>(tmp);

        }

      
    }
}
