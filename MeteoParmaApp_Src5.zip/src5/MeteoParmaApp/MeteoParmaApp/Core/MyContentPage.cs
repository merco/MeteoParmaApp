﻿using MeteoParmaApp.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MeteoParmaApp.Core
{
    public class MyContentPage : ContentPage
    {
        public MainPage MAIN_PAGE
        { get
            {

                return (MainPage)Application.Current.MainPage;
            } 
        
        }
    }
}
