﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using MeteoParmaApp.Views;

namespace MeteoParmaApp
{
    public partial class App : Application
    {

        public App()
        {
            InitializeComponent();

            //DependencyService.Register<MockDataStore>();
            MainPage = new MainPage();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
            MainPage mp = (MainPage)MainPage;
            mp.MySession.MainDataLoaded = false;
        }

        protected override void OnResume()
        {
        }
    }
}
