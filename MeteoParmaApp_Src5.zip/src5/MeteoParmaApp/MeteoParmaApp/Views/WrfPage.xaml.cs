﻿using MeteoParmaApp.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class WrfPage : MyContentPage
    {
        int lastIdx = 0;
        String[] hr = new string[8] { "+12h", "+18h", "+24h", "+30h", "+36h", "+42h", "+48h", "+60h" };
        public WrfPage()
        {
            InitializeComponent();
            BindingContext = this;
        }
        private void ShowData()
        {
            sli.Minimum = 0;
            sli.Maximum = 1;
            
            sli.Value = 0;
           
            if (MAIN_PAGE.MySession.CurrentWrfInfo == null) return;

            sli.Minimum = 0;
            sli.Value = 0;
            sli.Maximum = MAIN_PAGE.MySession.CurrentWrfInfo.Count-1;

        
            UpdateImage(0);

        }
        private void UpdateImage(int idx)
        {
            img.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(System.Convert.FromBase64String(MAIN_PAGE.MySession.CurrentWrfInfo[idx])));
            txtHr.Text = hr[idx];
        }
        protected override async void OnAppearing()
        {

            msg.Text = "!!! ATTESA meteoparma.com/wrf ...";
            this.IsEnabled = false;
            this.IsBusy = true;
            var s = await MAIN_PAGE.MySession.GetWrfData();
            msg.Text = "";
            if (!string.IsNullOrEmpty(s))
            {
                msg.Text = s;
            }
            this.IsBusy = false;


            this.IsEnabled = true;

            ShowData();

        }

        private void sli_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            var newStep = Math.Round(e.NewValue / 1.0d);

            int curIdx = (int)newStep;
            if (curIdx!=lastIdx)
            {
                UpdateImage(curIdx);
                lastIdx = curIdx;
            }
           
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            if (lastIdx == sli.Maximum) lastIdx = 0;
            else lastIdx = lastIdx + 1;
            UpdateImage(lastIdx);
            sli.Value = lastIdx;

        }
    }
}