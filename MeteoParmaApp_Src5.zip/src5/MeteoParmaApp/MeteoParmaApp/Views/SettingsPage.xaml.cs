﻿using MeteoParmaApp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace MeteoParmaApp.Views
{
	public partial class SettingsPage : MyContentPage
	{
		public SettingsPage ()
		{
			InitializeComponent ();
           
		}
        protected override void OnDisappearing()
        {
            base.OnDisappearing();

            if (cboComuni.SelectedIndex>=0)
            {

                Data.Comune cm = (Data.Comune)cboComuni.SelectedItem;
                MAIN_PAGE.MySession.CodiceComune = cm.Cod;
                MAIN_PAGE.MySession.SaveComune();
            }

        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (this.MAIN_PAGE == null) return;
            if (this.MAIN_PAGE.MySession == null) return;

            if (this.MAIN_PAGE.MySession.CurrentComuni != null)
            {
                this.cboComuni.ItemsSource = this.MAIN_PAGE.MySession.CurrentComuni;
                this.cboComuni.IsVisible = true;

                var theC = this.MAIN_PAGE.MySession.CurrentComuni.FirstOrDefault(X => X.Cod == this.MAIN_PAGE.MySession.CodiceComune);
                this.cboComuni.SelectedItem = theC;
            }
            else
            {
                this.cboComuni.IsVisible = false;
            }

        }
        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            Xamarin.Essentials.Launcher.OpenAsync("https://meteoparma.com/");

		}

        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            Xamarin.Essentials.Launcher.OpenAsync("mailto:d.mercanti@gmail.com");
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {
            Xamarin.Essentials.Launcher.OpenAsync("https://play.google.com/store/apps/developer?id=Luigi-Davide");
        }
    }
}

