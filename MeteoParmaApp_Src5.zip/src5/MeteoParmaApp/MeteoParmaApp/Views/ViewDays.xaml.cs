﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ViewDays : TabbedPage
    {
        DayPage P1;
        DayPage P2;
        DayPage P3;

        public MainPage MAIN_PAGE
        {
            get
            {

                return (MainPage)Application.Current.MainPage;
            }

        }
        protected override  void OnAppearing()
        {
            base.OnAppearing();
            if (MAIN_PAGE.MySession.CurrentWeatherInfo != null)
            {

                P1.Title = MAIN_PAGE.MySession.CurrentWeatherInfo.p[0].ShortDay();
                P1.wIndex = 0;
                P2.Title = MAIN_PAGE.MySession.CurrentWeatherInfo.p[1].ShortDay();
                P2.wIndex = 1;
                P3.Title = MAIN_PAGE.MySession.CurrentWeatherInfo.p[2].ShortDay();
                P3.wIndex = 2;
            }
            
        }
        public ViewDays()
        {
            InitializeComponent();
          
            
                P1 = new DayPage();
                P2 = new DayPage();
                P3 = new DayPage();

                Children.Add(P1);
                Children.Add(P2);
                Children.Add(P3);
           
           

        }
    }
}