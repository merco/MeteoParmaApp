﻿using Xamarin.Forms;
using MeteoParmaApp.Core;
using System.IO;

namespace MeteoParmaApp.Views
{
	public partial class TodayPage : MyContentPage
	{
		public TodayPage ()
		{
			BindingContext = this;
			InitializeComponent ();

			ShowCaptions(false);


		}
		private void ShowCaptions (bool toShow)
        {
			txtFreddeL.IsVisible = toShow;
			txtCaldeL.IsVisible = toShow;
			txtPiovoseL.IsVisible = toShow;
			txtVentoseL.IsVisible = toShow;
			txtNow.IsVisible = toShow;
			frm.IsVisible = toShow;
			accPC.IsVisible = toShow;
		}
		private void ShowData()
        {
			ShowCaptions(false);
			if (MAIN_PAGE.MySession.CurrentWeatherInfo != null)
            {
				ShowCaptions(true);

				var formattedString = new FormattedString();
				formattedString.Spans.Add(new Span { Text = MAIN_PAGE.MySession.CurrentWeatherInfo.NowCastingDate() + "\r\n" + "\r\n", ForegroundColor = Color.WhiteSmoke,  FontSize = Device.GetNamedSize(NamedSize.Title, typeof(Label))  });

				
				formattedString.Spans.Add(new Span { Text = MAIN_PAGE.MySession.CurrentWeatherInfo.NowCastingPrev(), FontAttributes = FontAttributes.Bold, FontSize = Device.GetNamedSize(NamedSize.Subtitle, typeof(Label)) });

				txtNow.FormattedText = formattedString;

				txtCalde.Text = MAIN_PAGE.MySession.CurrentWeatherInfo.caldeAsString();
				txtFredde.Text = MAIN_PAGE.MySession.CurrentWeatherInfo.freddeAsString();
				txtPiovose.Text = MAIN_PAGE.MySession.CurrentWeatherInfo.piovoseAsString();
				txtVentose.Text = MAIN_PAGE.MySession.CurrentWeatherInfo.ventoseAsString();

				imgt.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(System.Convert.FromBase64String(MAIN_PAGE.MySession.CurrentWeatherInfo.imgParmaTemp)));
				imgtl.Source = Xamarin.Forms.ImageSource.FromStream(() => new MemoryStream(System.Convert.FromBase64String(MAIN_PAGE.MySession.CurrentWeatherInfo.imgParmaTempLeg)));
			
			}


			if (MAIN_PAGE.MySession.CurrentPCInfo!=null)
            {
				accPC.HeaderBackgroundColor = MAIN_PAGE.MySession.CurrentPCInfo.GetWorstColor(0);

				PC1.BindingContext = MAIN_PAGE.MySession.CurrentPCInfo[0][0];
				PC2.BindingContext = MAIN_PAGE.MySession.CurrentPCInfo[0][1];
				PC3.BindingContext = MAIN_PAGE.MySession.CurrentPCInfo[0][2];


			}

		}
        protected override async void OnAppearing()
        {
            base.OnAppearing();
			ShowCaptions(false);
			if (!MAIN_PAGE.MySession.MainDataLoaded)
            {
				msg.Text = "!!! ATTESA meteoparma.com ...";
				this.IsEnabled = false;
				this.IsBusy = true;
				var s = await MAIN_PAGE.MySession.GetWeatherData();

				MAIN_PAGE.MySession.GetComuni();
				msg.Text = "";
				if (!string.IsNullOrEmpty(s))
                {
					msg.Text = s;
                } else
                {
					msg.Text = "!!! ATTESA dati P.C. ...";
					await MAIN_PAGE.MySession.GetPCData();
					msg.Text = "";
				}
				this.IsBusy = false;
				
				
				this.IsEnabled = true;

			}
			ShowData();

		}
		
       
    }
}

