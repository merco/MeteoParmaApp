﻿using MeteoParmaApp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CameraPage : MyContentPage
    {

        private bool UpdateNeeded = true;
        public CameraPage()
        {
            InitializeComponent();
            BindingContext = this;
        

        }

        protected override async void OnAppearing()
        {
            if (!UpdateNeeded)
            {
                UpdateNeeded = true;
                return;
            }
            msg.Text = "!!! ATTESA meteoparma.com/cams ...";
            this.IsEnabled = false;
            this.IsBusy = true;
            var s = await MAIN_PAGE.MySession.GetWebcamData();
            msg.Text = "";
            if (!string.IsNullOrEmpty(s))
            {
                msg.Text = s;
            }
            this.IsBusy = false;
            this.IsEnabled = true;
            LV.ItemsSource = MAIN_PAGE.MySession.CurrentWebCamInfo;

        }

        private async void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            var dp = new CameraZoomPage();
            TappedEventArgs aa = (TappedEventArgs)e;
            Image img = (Image)sender;
            Data.WebCamInfo CI = (Data.WebCamInfo)aa.Parameter;
            dp.Title = CI.text;
            dp.setImage( CI);
            UpdateNeeded = false;
            await Navigation.PushModalAsync(dp, true);

        }
    }
}