﻿using MeteoParmaApp.Core;
using MeteoParmaApp.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CameraZoomPage : MyContentPage
    {
        public CameraZoomPage()
        {
            InitializeComponent();
        }
        public void setImage(WebCamInfo ci)
        {

            lb.Text = ci.text;
            img.Source = ci.imm;

            img.Source = new UriImageSource
            {
                Uri = new Uri(ci.imm),
                CachingEnabled = true,
                CacheValidity = new TimeSpan(0, 0, 5, 0)
            };

        }

    }
}