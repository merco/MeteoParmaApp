﻿using MeteoParmaApp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MeteoParmaApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DayPage :  MyContentPage
    {
        public int wIndex
        { get; set; }

        private Data.WeatherInfoDetails WInfoDet;
        public DayPage()
        {
            InitializeComponent();
            wIndex = 0;
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            Show();
        }
        public void Show()
        {

            if (MAIN_PAGE.MySession.CurrentWeatherInfo == null) return;
            WInfoDet = MAIN_PAGE.MySession.CurrentWeatherInfo.p[wIndex];
            this.BindingContext = WInfoDet;

            M.InfoMain = MAIN_PAGE.MySession.CurrentWeatherInfo;
            M.ShowData(wIndex, "M");
            P.InfoMain = MAIN_PAGE.MySession.CurrentWeatherInfo;
            P.ShowData(wIndex, "P");
            S.InfoMain = MAIN_PAGE.MySession.CurrentWeatherInfo;
            S.ShowData(wIndex, "S");
        }
    }
}