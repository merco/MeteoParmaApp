<?php  
function getWebCamData($Node) {
	
	$dati = $Node->getElementsByTagName('img');
	
	$immagine=$dati[0]->getAttribute('src'); 
	$immagine=str_replace( array("\n","\t","\r"),"",$immagine);
	//echo "----",$immagine,"<br>";
	
	$dati = $Node->getElementsByTagName('span');
	$Nome=$dati[0]->childNodes[0]->textContent; 
	$Url=$dati[0]->childNodes[2]->nodeValue; 
		//echo "----",$Nome,"<br>";
		//echo "----",$Url,"<br>";
		
		
		$myObj->imm=$immagine;		//base64_encode(file_get_contents($immagine));
		$myObj->text=$Nome;
		$myObj->url=$Url;
		
		
		return $myObj;
}

libxml_use_internal_errors(true);
ini_set('max_execution_time', 3000);

$IMAGES= array();
$NOMI_GIORNI=array("", "", "");
$QUERY_PREVISIONI_MAIN  = "https://www.meteoparma.com/webcam-parma.php";

$pagecontent = file_get_contents($QUERY_PREVISIONI_MAIN);
$doc = new DOMDocument();
$doc->preserveWhiteSpace = false;
$doc->loadHTML($pagecontent);
$tables = $doc->getElementsByTagName('table');
//punto alla colonna della tabella principale, che contiene la tabella delle webcam
$nodoWebCam=$tables->item(11);
$cnt=0;
	
for ($i = 0; $i < $nodoWebCam->childNodes->length; $i++) {

	$riga= $nodoWebCam->childNodes[$i];
	
	
	if ($riga->childNodes->length==3) {
		
		for ($c = 0; $c < $riga->childNodes->length; $c++) {
		
		$colonna=$riga->childNodes[$c];
			//echo "| ",$i,",",$c,  " |", $colonna->nodeValue, "<BR>";
			
			$thisObj =getWebCamData($colonna);
			 $IMAGES[$cnt]=$thisObj;
			
			$cnt=$cnt+1;
		
	}
		
	}
	
	
	
	
	
}


ob_start('ob_gzhandler');

$myJSON = json_encode($IMAGES);
	echo $myJSON;
//echo $nodoWebCam->childNodes[0]->nodeValue,"<br>" ;
/*echo "----","<br>" ;
echo $cols->length,"<br>";
echo "----","<br>" ;
*/
unset($doc);
?>
