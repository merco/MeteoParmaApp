<?php  





libxml_use_internal_errors(true);
ini_set('max_execution_time', 3000);



$QUERY_PREVISIONI_MAIN  = "https://www.meteoparma.com/";



//recupero le informazioni di mattino-pomeriggio-sera per i 3gg di previsione
$myArr = array( 
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h12.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h18.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h24.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h30.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h36.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h42.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h48.png")),
				base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "wrf/rain6h54.png"))
				);
//e popolo la HASH table con le immagini B64 del meteo e della temperatura


ob_start('ob_gzhandler');



	$myJSON = json_encode($myArr);
	echo $myJSON;
	

?>
