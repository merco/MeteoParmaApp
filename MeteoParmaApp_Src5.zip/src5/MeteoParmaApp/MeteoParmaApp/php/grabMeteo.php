<?php  

function AddImageData($url) {
	global $IMAGES;
	global $QUERY_PREVISIONI_MAIN;
	
	if ($url!="") {
	 $imgdata="";
	 $imgdata=$IMAGES[$url];
	
		 if ($imgdata=="") {
			
			 $b64image = base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . $url));
			  $IMAGES[$url]=$b64image;
			
		 }
		
		
	}
	
	 
	
}
function NodeToWeather($Nome,$Node) {
	

 $myObj->day = $Nome;
 $myObj->lastUpdate = $Node->childNodes[0]->nodeValue;
 $colonne = $Node->childNodes[1]->getElementsByTagName('td');
 $dummy=null;


  $myObj->mattina = str_replace( array("\n","\t"),"",$colonne[0]->nodeValue);
  $dummy =$colonne[0]->getElementsByTagName('img');
 $myObj->mattina_1 = $dummy [0]->getAttribute('src'); 

  $myObj->mattina_2 = $dummy [1]->getAttribute('src'); 
  $myObj->mattina_3 = $dummy [2]->getAttribute('src'); 
  $myObj->mattina_T="";
    if ($dummy->length>=4) { $myObj->mattina_T =  $dummy[3]->getAttribute('src'); } 

 AddImageData($myObj->mattina_1);
 AddImageData($myObj->mattina_2);
 AddImageData($myObj->mattina_3);
 AddImageData($myObj->mattina_T); 
  
  $myObj->pomeriggio = str_replace( array("\n","\t"),"",$colonne[1]->nodeValue);
   $dummy =$colonne[1]->getElementsByTagName('img');
  $myObj->pomeriggio_1 = $dummy[0]->getAttribute('src'); 
  $myObj->pomeriggio_2 = $dummy[1]->getAttribute('src'); 
  $myObj->pomeriggio_3 = $dummy[2]->getAttribute('src');
  $myObj->pomeriggio_T="";  
   if ($dummy->length>=4) { $myObj->pomeriggio_T =  $dummy[3]->getAttribute('src');} 
   AddImageData($myObj->pomeriggio_1);
 AddImageData($myObj->pomeriggio_2);
 AddImageData($myObj->pomeriggio_3);
 AddImageData($myObj->pomeriggio_T); 

  $myObj->sera = str_replace( array("\n","\t"),"",$colonne[2]->nodeValue);
   $dummy =$colonne[2]->getElementsByTagName('img');
  $myObj->sera_1 = $dummy [0]->getAttribute('src'); 
  $myObj->sera_2 = $dummy [1]->getAttribute('src'); 
  $myObj->sera_3 =$dummy [2]->getAttribute('src'); 
   $myObj->sera_T="";
   
   if ($dummy->length>=4) {$myObj->sera_T =  $dummy[3]->getAttribute('src'); }
    AddImageData($myObj->sera_1);
 AddImageData($myObj->sera_2);
 AddImageData($myObj->sera_3);
 AddImageData($myObj->sera_T); 
   
  
   $myObj->previsione= $colonne[3]->childNodes[0]->nodeValue;
   $myObj->temperature= $colonne[3]->childNodes[2]->nodeValue;
   $myObj->venti= $colonne[3]->childNodes[4]->nodeValue;
  

 return $myObj;
}


$IMAGES= array();
libxml_use_internal_errors(true);
ini_set('max_execution_time', 3000);


$NOMI_GIORNI=array("", "", "");
$QUERY_PREVISIONI_MAIN  = "https://www.meteoparma.com/";

$pagecontent = file_get_contents($QUERY_PREVISIONI_MAIN);
$doc = new DOMDocument();
$doc->preserveWhiteSpace = false;
$doc->loadHTML($pagecontent);
$tables = $doc->getElementsByTagName('table');

$marquee = $doc->getElementsByTagName('marquee');
$nowCasting=  str_replace( array("\n","\t"),"",$marquee[0]->childNodes[1]->nodeValue);

//punto alla colonna della tabella principale, che contiene la tabella della previsione 3giornaliera
$nodoPrevisione=$tables->item(2)->childNodes[0]->childNodes[4]->childNodes[2];
$giorni = $nodoPrevisione->childNodes[1]->getElementsByTagName('li');
if ( $giorni->length>=4) {
	for ($i = 0; $i < 3; $i++) {
		$NOMI_GIORNI[$i]=$giorni[$i]->nodeValue;
	}
}
//recupero le informazioni di mattino-pomeriggio-sera per i 3gg di previsione
$myArr = array( NodeToWeather($NOMI_GIORNI[0],$nodoPrevisione->childNodes[2]->childNodes[1]),
				NodeToWeather($NOMI_GIORNI[1],$nodoPrevisione->childNodes[2]->childNodes[3]),
				NodeToWeather($NOMI_GIORNI[2],$nodoPrevisione->childNodes[2]->childNodes[5]));
//e popolo la HASH table con le immagini B64 del meteo e della temperatura
$myData->i=$IMAGES;
$myData->p=$myArr;
ob_start('ob_gzhandler');



    $nodoStatistica=$tables->item(2)->childNodes[0]->childNodes[4]->childNodes[8];
	
	$statistiche = $nodoStatistica->getElementsByTagName('li');
	

	
	$myData->fredde=array( $statistiche[0]->nodeValue, $statistiche[1]->nodeValue, $statistiche[2]->nodeValue);
	$myData->calde=array( $statistiche[3]->nodeValue, $statistiche[4]->nodeValue, $statistiche[5]->nodeValue);
	$myData->ventose=array( $statistiche[6]->nodeValue, $statistiche[7]->nodeValue, $statistiche[8]->nodeValue);
	$myData->piovose=array( $statistiche[9]->nodeValue, $statistiche[10]->nodeValue, $statistiche[11]->nodeValue);
	
	$myData->imgTemp=base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "img/temperature.php"));
	$myData->imgParma=base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "img/parmamap.jpg"));
	$myData->imgParmaTemp=base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "img/temperature.php"));
	$myData->imgParmaTempLeg=base64_encode(file_get_contents($QUERY_PREVISIONI_MAIN . "img/legendatemp.jpg"));
	$myData->nowCasting=$nowCasting;
	$myJSON = json_encode($myData);
	echo $myJSON;
	/*
for ($i = 2; $i < $tables->item(2)->childNodes[0]->childNodes[4]->childNodes->length; $i++) {


		echo "| ",$i, " |", $nodoStatistica->nodeValue, "<BR>";
}
*/

/*
echo $rows->length,"<br>" ;
echo "----","<br>" ;
echo $cols->length,"<br>";
echo "----","<br>" ;
*/
unset($doc);
?>
