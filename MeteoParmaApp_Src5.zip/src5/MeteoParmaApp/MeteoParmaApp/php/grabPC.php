<?php  



$RISCHIGG=array("", "");
$RISCHI=array("", "","");
libxml_use_internal_errors(true);
ini_set('max_execution_time', 3000);


$CITTA="";
if (isset($_GET['C'])) {
    $CITTA= $_GET['C'];
} else {
    // Fallback behaviour goes here
	$CITTA="034027";
}

$json="";
//verde (default) | gialla | arancione | rossa 

$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=" . $CITTA ."&rischio=idraulico&allerta=verde&giorno=oggi&formato=json");
$tempObj=json_decode ($json);
$myobjI->R=$tempObj->previsione->risk;
$myobjI->I=$tempObj->previsione->info;
$myobjI->A=$tempObj->previsione->alert;
$RISCHI[0]=$myobjI;

$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=" . $CITTA ."&rischio=idrogeologico&allerta=verde&giorno=oggi&formato=json");
$tempObj=json_decode ($json);
$myobjA->R=$tempObj->previsione->risk;
$myobjA->I=$tempObj->previsione->info;
$myobjA->A=$tempObj->previsione->alert;
$RISCHI[1]=$myobjA;

$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=" . $CITTA ."&rischio=temporali&allerta=verde&giorno=oggi&formato=json");
$tempObj=json_decode ($json);
$myobjT->R=$tempObj->previsione->risk;
$myobjT->I=$tempObj->previsione->info;
$myobjT->A=$tempObj->previsione->alert;
$RISCHI[2]=$myobjT;

$RISCHIGG[0]=$RISCHI;
/*
//domani
$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=034027&rischio=idraulico&allerta=verde&giorno=domani&formato=json");
$tempObj=json_decode ($json);
$myobjID->R=$tempObj->previsione->risk;
$myobjID->I=$tempObj->previsione->info;
$myobjID->A=$tempObj->previsione->alert;
$RISCHI[0]=$myobjID;

$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=034027&rischio=idrogeologico&allerta=verde&giorno=domani&formato=json");
$tempObj=json_decode ($json);
$myobjAD->R=$tempObj->previsione->risk;
$myobjAD->I=$tempObj->previsione->info;
$myobjAD->A=$tempObj->previsione->alert;
$RISCHI[1]=$myobjAD;

$json=file_get_contents("http://www.protezionecivilepop.tk/allerte?citta=034027&rischio=temporali&allerta=verde&giorno=domani&formato=json");
$tempObj=json_decode ($json);
$myobjTD->R=$tempObj->previsione->risk;
$myobjTD->I=$tempObj->previsione->info;
$myobjTD->A=$tempObj->previsione->alert;
$RISCHI[2]=$myobjTD;


$RISCHIGG[1]=$RISCHI;
*/

ob_start('ob_gzhandler');



$myJSON = "";
	$myJSON = json_encode($RISCHIGG);
	echo $myJSON;
	

?>